<?php
session_start();
print(var_dump($_SESSION));
?>