# alyocord
Alyocord Project

clone or download as zip; free and OSS using MIT license 

# notes 
None of this is secure whatsoever so please don't legitimately use this if you think it's good security wise. I only made this public to show how products should be improved.

# Contributions

Push any updates to the [master branch](https://github.com/alyocord/alyocord/tree/master), any other branch(es) are for security testing and are not designed to be a working nor secure branch. 


# Support
For support on the repository itself please contact the maintainer. Plus, you're smart enough to be a developer, so I hope you at least know how GitHub works
